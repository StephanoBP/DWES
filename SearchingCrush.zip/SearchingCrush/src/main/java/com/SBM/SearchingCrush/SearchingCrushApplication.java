package com.SBM.SearchingCrush;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SearchingCrushApplication {

	public static void main(String[] args) {
		SpringApplication.run(SearchingCrushApplication.class, args);
	}

}
